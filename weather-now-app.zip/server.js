// server.js
require('dotenv').config(); // Must be at the top

const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const cors = require('cors');


const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI;
const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY;

app.use(express.static('weather'));


// MongoDB Connection
mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ MongoDB connected"))
.catch((err) => console.error("❌ MongoDB connection error:", err));

// Mongoose Schema & Model
const CitySchema = new mongoose.Schema({
  name: { type: String, unique: true, required: true }
});
const City = mongoose.model('City', CitySchema);

// Middleware
app.use(cors());
app.use(express.json());

// API to get current weather
app.get('/api/weather', async (req, res) => {
  const city = req.query.city;
  if (!city) return res.status(400).json({ error: 'City is required' });

  try {
    await City.updateOne({ name: city }, { name: city }, { upsert: true });

    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${OPENWEATHER_API_KEY}&units=metric`;
    const response = await axios.get(weatherUrl);
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch weather', details: err.message });
  }
});

// API to get forecast
app.get('/api/forecast', async (req, res) => {
  const city = req.query.city;
  if (!city) return res.status(400).json({ error: 'City is required' });

  try {
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${OPENWEATHER_API_KEY}&units=metric`;
    const response = await axios.get(forecastUrl);
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch forecast', details: err.message });
  }
});

// API to get search history
app.get('/api/history', async (req, res) => {
  try {
    const cities = await City.find().sort({ _id: -1 }).limit(10);
    res.json(cities.map(city => city.name));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch history', details: err.message });
  }
});

// API to delete city from history
app.delete('/api/history/:city', async (req, res) => {
  const city = req.params.city;
  try {
    await City.deleteOne({ name: city });
    res.json({ message: 'City deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete city', details: err.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});

// // Example: get weather of city
// fetch(`/api/weather?city`)
//   .then(res => res.json())
//   .then(data => console.log(data))
//   .catch(err => console.error(err));
