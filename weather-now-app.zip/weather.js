let tempChart = null; // Global Chart.js chart instance

// ✅ Use your own backend for city weather
async function getWeather(cityNameFromHistory = null) {
  const input = document.getElementById('cityInput');
  const city = cityNameFromHistory || input.value.trim();

  if (!city) {
    alert('Please enter a city name');
    return;
  }

  const url = `/api/weather?city=${encodeURIComponent(city)}`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod === '404') {
      document.getElementById('weatherResult').innerHTML = 'City not found!';
      document.getElementById('forecastResult').innerHTML = '';
      clearChart();
    } else {
      showWeatherData(data);
      getForecast(data.name);
      showHistory(); // Refresh history after saving (since it's saved server-side)
    }
  } catch (error) {
    console.error('Error fetching weather:', error);
    document.getElementById('weatherResult').innerHTML = 'Error fetching data';
    clearChart();
  }
}

// ✅ Use your own backend for location weather
async function getWeatherByLocation(lat, lon) {
  const url = `/api/weather/location?lat=${lat}&lon=${lon}`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod === 200) {
      showWeatherData(data);
      getForecast(data.name);
      showHistory();
    } else {
      document.getElementById('weatherResult').innerHTML = 'Location not found!';
      clearChart();
    }
  } catch (error) {
    console.error('Error fetching location weather:', error);
    document.getElementById('weatherResult').innerHTML = 'Error fetching location weather';
    clearChart();
  }
}

function showWeatherData(data) {
  const sunrise = new Date(data.sys.sunrise * 1000).toLocaleTimeString();
  const sunset = new Date(data.sys.sunset * 1000).toLocaleTimeString();
  const icon = data.weather[0].icon;
  const countryFlag = `https://flagsapi.com/${data.sys.country}/flat/64.png`;

  updateBackgroundVideo(data.weather[0].main);

  const weatherDiv = document.getElementById('weatherResult');
  const forecastDiv = document.getElementById('forecastResult');

  // Ensure 3D class is present
  weatherDiv.classList.add('weather-3d');
  forecastDiv.classList.add('weather-3d');

  // Inject content
  weatherDiv.innerHTML = `
    <h2>${data.name}, ${data.sys.country} <img src="${countryFlag}" alt="Flag" width="30"></h2>
    <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="icon" />
    <p><strong>Temperature:</strong> ${data.main.temp}°C</p>
    <p><strong>Weather:</strong> ${data.weather[0].description}</p>
    <p><strong>Humidity:</strong> ${data.main.humidity}%</p>
    <p><strong>Wind Speed:</strong> ${data.wind.speed} m/s</p>
    <p><strong>Pressure:</strong> ${data.main.pressure} hPa</p>
    <p><strong>Sunrise:</strong> ${sunrise}</p>
    <p><strong>Sunset:</strong> ${sunset}</p>
  `;
  document.getElementById('weatherResult').style.display = 'block';
  document.querySelector('.app-box').style.top = '30px';
  document.querySelector('.app-box').style.transform = 'translate(-50%, 0)';


  // Animate only AFTER injecting content
  setTimeout(() => {
    weatherDiv.classList.remove('weather-animate-3d'); // reset animation
    void weatherDiv.offsetWidth; // trigger reflow
    weatherDiv.classList.add('weather-animate-3d');
  }, 10);

  // Clear old forecast to prepare for new (which gets rendered from getForecast)
  forecastDiv.innerHTML = '';
}

// ✅ Forecast still uses frontend fetch with your API key
const apiKey = 'fbb6ffc5680debaac29d642dcc66f480';

async function getForecast(city) {
  const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(forecastUrl);
    const data = await response.json();

    if (data.cod === "200") {
      displayForecast(data);
    } else {
      document.getElementById('forecastResult').innerHTML = '';
      clearChart();
    }
  } catch (error) {
    console.error("Forecast error:", error);
    clearChart();
  }
}

function displayForecast(data) {
  const forecastSection = document.getElementById('forecastSection');
  const forecastDiv = document.getElementById('forecastResult');

  // Show the forecast section
  forecastSection.style.display = 'block';

  // Clear any old forecast cards
  forecastDiv.innerHTML = '';

  const dailyData = data.list.filter(item => item.dt_txt.includes("12:00:00"));

  const labels = [];
  const temps = [];

  dailyData.forEach(item => {
    const date = new Date(item.dt_txt).toLocaleDateString();
    const temp = item.main.temp;
    const desc = item.weather[0].description;
    const icon = item.weather[0].icon;

    labels.push(date);
    temps.push(temp);

    const card = document.createElement('div');
    card.className = 'forecast-card';
    card.innerHTML = `
      <p><strong>${date}</strong></p>
      <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="${desc}" />
      <p>${temp}°C</p>
      <p>${desc}</p>
    `;

    forecastDiv.appendChild(card);
  });

  const ctx = document.getElementById('tempChart').getContext('2d');

  if (tempChart) {
    tempChart.data.labels = labels;
    tempChart.data.datasets[0].data = temps;
    tempChart.update();
  } else {
    tempChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
  label: 'Temperature (°C)',
  data: temps,
  fill: false,
  borderColor: '#00ffff',
  borderWidth: 3,
  tension: 0.4,
  pointRadius: 5,
  pointHoverRadius: 7,
  pointBackgroundColor: '#00ffff',
}]

      },
      options: {
  responsive: true,
  plugins: {
    legend: {
      labels: {
        color: '#ffffff',
        font: {
          size: 14
        }
      }
    }
  },
  scales: {
    x: {
      ticks: { color: '#ffffff' },
      grid: { color: 'rgba(255,255,255,0.1)' }
    },
    y: {
      beginAtZero: false,
      ticks: { color: '#ffffff' },
      grid: { color: 'rgba(255,255,255,0.1)' }
    }
  }
}

    });
  }
}

function clearChart() {
  if (tempChart) {
    tempChart.destroy();
    tempChart = null;
  }
}

function getUserLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      position => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        getWeatherByLocation(lat, lon);
      },
      error => {
        console.error('Geolocation error:', error.message);
        document.getElementById('weatherResult').innerText = 'Location access denied.';
        clearChart();
      }
    );
  } else {
    document.getElementById('weatherResult').innerText = 'Geolocation not supported.';
    clearChart();
  }
}

// Delete city from search history in MongoDB
async function deleteHistory(city) {
  try {
    const response = await fetch(`/api/history/${encodeURIComponent(city)}`, {
      method: 'DELETE'
    });

    if (response.ok) {
      showHistory(); // Refresh after delete
    } else {
      console.error('Failed to delete history');
    }
  } catch (error) {
    console.error('Error deleting history:', error);
  }
}

// Show search history fetched from MongoDB backend
async function showHistory() {
  try {
    const response = await fetch('/api/history');
    const cities = await response.json();

    const historyDiv = document.getElementById('searchHistory');
    historyDiv.innerHTML = '<h3>Recent Searches</h3>';

    cities.forEach(city => {
    const pill = document.createElement('div');
pill.className = 'city-pill';
pill.innerHTML = `📍 ${city}`;
pill.onclick = () => {
  document.getElementById('cityInput').value = city;
  getWeather(city);
};

const delBtn = document.createElement('button');
delBtn.className = 'delete-btn';
delBtn.innerText = '✖';
delBtn.onclick = () => deleteHistory(city);

const div = document.createElement('div');
div.className = 'history-item';
div.appendChild(pill);
div.appendChild(delBtn);

historyDiv.appendChild(div);
    });
  } catch (error) {
    console.error('Error loading history:', error);
  }
}

// On page load, show search history from backend
window.onload = function () {
  const w1 = document.getElementById("word1");
  const w2 = document.getElementById("word2");
  const mainApp = document.getElementById("mainApp");

  // Slide out text after bloom
  setTimeout(() => {
    w1.style.animation = "slide-left 2s forwards";
    w2.style.animation = "slide-right 2s forwards";
  }, 2000);

  // After intro, hide intro and show UI
  setTimeout(() => {
    const intro = document.getElementById("intro");
    intro.style.opacity = 0;

    setTimeout(() => {
      intro.style.display = "none";

      // Show and fade-in main UI
      mainApp.classList.remove("hidden");
      mainApp.classList.add("show");

      document.getElementById("cityInput").focus();
      updateBackgroundVideo("Mist");
      showHistory();
    }, 1500);
  }, 4000);
};


function updateBackgroundVideo(weatherMain) {
  const bgVideo = document.getElementById("bgVideo");
  const source = bgVideo.querySelector("source");

  const weatherVideos = {
    Clear: "sunny.mp4",
    Clouds: "cloudy.mp4",
    Rain: "rainy.mp4",
    Drizzle: "rainy.mp4",
    Thunderstorm: "storm.mp4",
    Snow: "snow.mp4",
    Mist: "mist.mp4",
    Smoke: "mist.mp4",
    Haze: "mist.mp4",
    Dust: "mist.mp4",
    Fog: "mist.mp4",
    Sand: "mist.mp4",
    Ash: "mist.mp4",
    Squall: "storm.mp4",
    Tornado: "storm.mp4"
  };

  const selectedVideo = weatherVideos[weatherMain] || "default.mp4";

  const fadeAndSwitch = () => {
    if (source.getAttribute("src") !== selectedVideo) {
      // Step 1: Fade out slightly
      bgVideo.style.opacity = "0.2";

      // Step 2: After fade out, switch the video
      setTimeout(() => {
        source.setAttribute("src", selectedVideo);
        bgVideo.load();

        bgVideo.play().then(() => {
          // Step 3: Fade back in smoothly
          bgVideo.style.opacity = "1";
          console.log("▶️ Background video updated and playing");
        }).catch(err => {
          console.error("🚫 Video playback failed:", err);
        });
      }, 1000); // 1s = match the fade time
    }
  };

  // Wait until intro is gone
  const intro = document.getElementById("intro");

  const observer = new MutationObserver(() => {
    if (getComputedStyle(intro).display === "none") {
      fadeAndSwitch();
      observer.disconnect();
    }
  });

  observer.observe(intro, { attributes: true, attributeFilter: ["style"] });

  // Fallback in case MutationObserver doesn't fire
  setTimeout(() => {
    if (getComputedStyle(intro).display === "none") {
      fadeAndSwitch();
    }
  }, 4000);
}
